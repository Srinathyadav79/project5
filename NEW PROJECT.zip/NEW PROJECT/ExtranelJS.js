// this script for navbar
let view = document.getElementById("service-hover-container");
view.style.cssText = "display:none;"

let hover = document.getElementById("click");
let background = document.getElementById("background");
let bnner = document.getElementById('bnner-content-h1')
hover.addEventListener('mouseover', function () {
    view.style.display = "block";
    // background.style.cssText = "background-color:white;";
    bnner.style.cssText = "z-index: -1;"

});
let hover_out = document.getElementById("service-hover-container");
hover_out.addEventListener('click', function () {
    view.style.cssText = "display:none;"
    background.style.cssText = "background-color:none;"
    bnner.style.cssText = "z-index: 1;"
});


let left_padd = document.getElementById("left-pad");
left_padd.addEventListener('mouseenter', function () {
    left_padd.style.cssText = "padding-left:10px;"
})

// js for navbar
window.addEventListener("scroll", function () {
    let navbar = document.getElementById("background");

    if (window.pageYOffset >= 119) {
        navbar.classList.add('sticky');
        navbar.style.cssText = " position:fixed;z-index:1;"
        view.classList.add('sticky')
    }
    else {
        navbar.classList.remove('sticky');
        navbar.style.cssText = "background:none;"
        list.style.cssText = "color:none;"
    }

})