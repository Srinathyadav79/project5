// this script for navbar
let view = document.getElementById("service-hover-container");
view.style.cssText = "display:none;"

let hover = document.getElementById("click");
let background = document.getElementById("background");
hover.addEventListener('mouseover', function () {
    view.style.display = "block";
    // background.style.cssText = "background-color:white;";

});
let hover_out = document.getElementById("service-hover-container");
hover_out.addEventListener('click', function () {
    view.style.cssText = "display:none;"
    background.style.cssText = "background-color:none;"
});


let left_padd = document.getElementById("left-pad");
left_padd.addEventListener('mouseenter', function () {
    left_padd.style.cssText = "padding-left:10px;"
})

// js for navbar
window.addEventListener("scroll", function () {
    let navbar = document.getElementById("background");

    if (window.pageYOffset >= 119) {
        navbar.classList.add('sticky');
        navbar.style.cssText = " position:fixed;z-index:1;"
        view.classList.add('sticky')
    }
    else {
        navbar.classList.remove('sticky');
        navbar.style.cssText = "background:none;"
        list.style.cssText = "color:none;"
    }

})

// this script for home page

let count = 1;
const counter = document.getElementById("counter");
const interval = setInterval(() => {
    counter.textContent = count;
    count++;
    if (count > 20) {
        clearInterval(interval);
        counter.textContent = "20+";
    }
}, 100);

// this script for pop-up
// for automobile
const openBtn1 = document.getElementById('openAutomobilePopupBtn');
const closeBtn1 = document.getElementById('closePopupBtn');
const popup1 = document.getElementById('socialPopup');

openBtn1.addEventListener('click', () => {
    popup1.classList.add('active');
});

closeBtn1.addEventListener('click', () => {
    popup1.classList.remove('active');
});
// for beauty
const openBtn2 = document.getElementById('openBeautyPopupBtn');
const closeBtn2 = document.getElementById('closebeautyPopupBtn');
const popup2 = document.getElementById('beautypopup');
openBtn2.addEventListener('click', () => {
    popup2.classList.add('active');
});

closeBtn2.addEventListener('click', () => {
    popup2.classList.remove('active');
});
// for Construction
const openBtn3 = document.getElementById('openConstructionPopupBtn');
const closeBtn3 = document.getElementById('closeConstructionPopupBtn');
const popup3 = document.getElementById('Constructionpopup');
openBtn3.addEventListener('click', () => {
    popup3.classList.add('active');
});

closeBtn3.addEventListener('click', () => {
    popup3.classList.remove('active');
});

// for Construction
const openBtn4 = document.getElementById('openCorporatePopupBtn');
const closeBtn4 = document.getElementById('closeCorporatePopupBtn');
const popup4 = document.getElementById('Corporatepopup');
openBtn4.addEventListener('click', () => {
    popup4.classList.add('active');
});

closeBtn4.addEventListener('click', () => {
    popup4.classList.remove('active');
});

// for Construction
const openBtn5 = document.getElementById('openEducationPopupBtn');
const closeBtn5 = document.getElementById('closeEducationPopupBtn');
const popup5 = document.getElementById('Educationpopup');
openBtn5.addEventListener('click', () => {
    popup5.classList.add('active');
});

closeBtn5.addEventListener('click', () => {
    popup5.classList.remove('active');
});

// for Electronics
const openBtn6 = document.getElementById('openElectronicPopupBtn');
const closeBtn6 = document.getElementById('closeElectronicsPopupBtn');
const popup6 = document.getElementById('Electronicspopup');
openBtn6.addEventListener('click', () => {
    popup6.classList.add('active');
});

closeBtn6.addEventListener('click', () => {
    popup6.classList.remove('active');
});


// for Travel
const openBtn7 = document.getElementById('openTravelPopupBtn');
const closeBtn7 = document.getElementById('closeTravelPopupBtn');
const popup7 = document.getElementById('Travelpopup');
openBtn7.addEventListener('click', () => {
    popup7.classList.add('active');
});

closeBtn7.addEventListener('click', () => {
    popup7.classList.remove('active');
});

// for Construction
const openBtn8 = document.getElementById('openCorporatePopupBtn');
const closeBtn8 = document.getElementById('closeCorporatePopupBtn');
const popup8 = document.getElementById('Corporatepopup');
openBtn8.addEventListener('click', () => {
    popup8.classList.add('active');
});

closeBtn8.addEventListener('click', () => {
    popup8.classList.remove('active');
});

// for Construction
const openBtn9 = document.getElementById('openCorporatePopupBtn');
const closeBtn9 = document.getElementById('closeCorporatePopupBtn');
const popup9 = document.getElementById('Corporatepopup');
openBtn9.addEventListener('click', () => {
    popup9.classList.add('active');
});

closeBtn9.addEventListener('click', () => {
    popup9.classList.remove('active');
});





function openPanel(title) {
    document.getElementById('panelTitle').innerText = title;
    document.getElementById('slidePanel').classList.add('active');
}
function closePanel() {
    document.getElementById('slidePanel').classList.remove('active');
}
