// this script for navbar
let view = document.getElementById("service-hover-container");
view.style.cssText = "display:none;"

let hover = document.getElementById("click");
let background = document.getElementById("background");
hover.addEventListener('mouseover', function () {
  view.style.display="block";
  // background.style.cssText = "background-color:white;";

});
let hover_out = document.getElementById("service-hover-container");
hover_out.addEventListener('click', function () {
  view.style.cssText = "display:none;"
  background.style.cssText = "background-color:none;"
});


let left_padd = document.getElementById("left-pad");
left_padd.addEventListener('mouseenter', function () {
  left_padd.style.cssText = "padding-left:10px;"
})

// js for navbar
window.addEventListener("scroll" ,function(){
  let navbar=  document.getElementById("background");

  if(window.pageYOffset >=119){
      navbar.classList.add('sticky');
      navbar.style.cssText =" position:fixed;z-index:1;"
      view.classList.add('sticky')
  }
  else{
      navbar.classList.remove('sticky');
      navbar.style.cssText ="background:none;"
       list.style.cssText ="color:none;"
  }

})

// slider js
let flag = 0;
function controller(x) {
  flag = flag + x;
  slideshow(flag);
}
slideshow(flag);

function slideshow(num) {
  let slides = document.getElementsByClassName("slide");
  if (num == slides.length) {
    flag = 0;
    num = 0;
  }
  if (num < 0) {
    flag = slides.length - 1;
    num = slides.length - 1;
  }
  for (let y of slides) {
    y.style.display = "none";
  }
  slides[num].style.display = "block";
}


// js for scoroll section 

let scr = document.getElementById('scroll');
let home = document.getElementById('home-scroll');
let Design = document.getElementById('Design-scroll');
let bulid = document.getElementById("build-scroll");
let market = document.getElementById('Market-scroll');
scr.addEventListener('scroll', function () {
  if (window.pageYOffset > 400) {
    Design.style.display = "block";
    home.style.display = "none";

  } else {
    Design.style.display = "none";
    home.style.display = "block";

  }
});

window.addEventListener('scroll', function () {
  if (window.pageYOffset > 620) {
    bulid.style.display = "block"
    Design.style.display = "none";
    home.style.display = "none";
  } else {
    bulid.style.display = "none"
    Design.style.display = "block";
  }
});
window.addEventListener('scroll', function () {
  if (window.pageYOffset > 820) {
    market.style.display = "block"
    bulid.style.display = "none";
    home.style.display = "none";
  } else {
    market.style.display = "none";
    bulid.style.display = "block";
  }
});


// hidden js section start

let view2 =document.getElementById('hidden-container');
function view1(){
  view2.style.display="block";
}
let hide = document.getElementById('crox-btn');
hide.addEventListener('click',function(){
  view2.style.display="none";
})