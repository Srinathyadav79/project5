// if (window.pageYOffset>=360) {
//     let ourServices = document.getElementById('ourServices-text');
//     ourServices.style.cssText ="overflow-y: scroll;"
// } else {

// }
window.addEventListener("scroll", function () {
    let ourServices = document.getElementById('ourServices-text');
    if (window.pageYOffset >= 160) {
        ourServices.style.cssText = "overflow-y: scroll;"
        console.log("scrolling..")
    }
    else   {
        ourServices.style.cssText = "overflow-y: hidden;"
        console.log(" notscrolling..")
    }
})
window.addEventListener("scroll", function () {
    let ourServices2 = document.getElementById('ourServices-text2');
    if (window.pageYOffset >= 180) {
        ourServices2.style.cssText = "overflow-y: scroll;"
        console.log("scrolling..")
    }
    else   {
        ourServices2.style.cssText = "overflow-y: hidden;"
        console.log(" notscrolling..")
    }
})
window.addEventListener("scroll", function () {
    let ourServices3 = document.getElementById('ourServices-text3');
    if (window.pageYOffset >= 200) {
        ourServices3.style.cssText = "overflow-y: scroll;"
        console.log("scrolling..")
    }
    else   {
        ourServices3.style.cssText = "overflow-y: hidden;"
        console.log(" notscrolling..")
    }
})
window.addEventListener("scroll", function () {
    let ourServices4 = document.getElementById('ourServices-text4');
    if (window.pageYOffset >= 220) {
        ourServices4.style.cssText = "overflow-y: scroll;"
        console.log("scrolling..")
    }
    else   {
        ourServices4.style.cssText = "overflow-y: hidden;"
        console.log(" notscrolling..")
    }
})