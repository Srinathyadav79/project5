// this script for navbar
let view = document.getElementById("service-hover-container");
view.style.cssText = "display:none;"

let hover = document.getElementById("click");
let background = document.getElementById("background");
hover.addEventListener('mouseover', function () {
    view.style.display = "block";
    // background.style.cssText = "background-color:white;";

});
let hover_out = document.getElementById("service-hover-container");
hover_out.addEventListener('click', function () {
    view.style.cssText = "display:none;"
    background.style.cssText = "background-color:none;"
});


let left_padd = document.getElementById("left-pad");
left_padd.addEventListener('mouseenter', function () {
    left_padd.style.cssText = "padding-left:10px;"
})

// js for navbar
window.addEventListener("scroll", function () {
    let navbar = document.getElementById("background");

    if (window.pageYOffset >= 119) {
        navbar.classList.add('sticky');
        navbar.style.cssText = " position:fixed;z-index:1;"
        view.classList.add('sticky')
    }
    else {
        navbar.classList.remove('sticky');
        navbar.style.cssText = "background:none;"
        list.style.cssText = "color:none;"
    }

})


// this script for dropdown
// Add show class to rotate arrow
const dropdownToggle = document.getElementById('industriesDropdown');
dropdownToggle.addEventListener('click', function () {
    this.classList.toggle('show');
});

// Optional: Close dropdown when clicking outside
document.addEventListener('click', function (event) {
    const isClickInside = dropdownToggle.contains(event.target) || document.querySelector('.dropdown-menu').contains(event.target);

    if (!isClickInside) {
        dropdownToggle.classList.remove('show');
    }
});

// this script for cursor
var main = document.querySelector("#main");
var cursor = document.querySelector("#cursor");
var imageDiv = document.querySelector(".image")

main.addEventListener("mousemove", function (dets) {
    gsap.to(cursor, {
        x: dets.x,
        y: dets.y,
        duration: 0.1,
    })
})

imageDiv.addEventListener("mouseenter", function () {
    cursor.innerHTML = "Click"
    gsap.to(cursor, {
        scale: 4,
        backgroundColor: "rgba(112, 106, 106, 0.66)",
        color: "#fff",
        opacity: "1"
    })

})

imageDiv.addEventListener("mouseleave", function () {
    cursor.innerHTML = ""
    gsap.to(cursor, {
        scale: 0,
        backgroundColor: "none"
    })
})

// this script for side popup
function openPopup() {
    document.getElementById("sidePopup-open").classList.add("open");
}

function closePopup() {
    document.getElementById("sidePopup-open").classList.remove("open");
}
